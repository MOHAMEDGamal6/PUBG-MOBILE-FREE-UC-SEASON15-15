<div class="menu-notify">
<a href="javascript:;" onclick="buka('pages/uc');"><div class="menu-notify-change">Change Reward</div></a>
<div class="menu-notify-icon"><i class="zmdi zmdi-info-outline"></i></div>
<div class="menu-notify-txt">Hi survivor, this is the other reward for you</div>
</div> <!--- menu-notify --->
<div class="scroll">
<div class="item kanan">
<img src="https://i.ibb.co/S78nnmC/1.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/S78nnmC/1.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/Lk3B2mw/2.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/Lk3B2mw/2.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/YpbSGGN/3.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/YpbSGGN/3.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/54C3TwS/1.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/54C3TwS/1.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/8rwnBbf/2.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/8rwnBbf/2.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/JyKsRV9/3.jpg">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/JyKsRV9/3.jpg">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/9NW5RBs/1.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/9NW5RBs/1.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/DrzYVS0/2.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/DrzYVS0/2.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/3cM96Bn/3.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/3cM96Bn/3.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/30shkpG/4.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/30shkpG/4.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/DYcd3r8/5.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/DYcd3r8/5.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/m5MfkNp/6.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/m5MfkNp/6.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/0hG72h9/7.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/0hG72h9/7.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/c232k1x/8.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/c232k1x/8.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/smrqkwd/9.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/smrqkwd/9.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/stysM7v/10.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/stysM7v/10.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/WgYyGnw/11.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/WgYyGnw/11.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/pdYW33J/12.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/pdYW33J/12.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/N9XVcKh/13.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/N9XVcKh/13.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/X8Y41sj/14.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/X8Y41sj/14.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/mhWQMvq/15.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/mhWQMvq/15.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/Rjh4zr4/16.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/Rjh4zr4/16.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/qB0F8jV/17.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/qB0F8jV/17.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/n8pTPFf/18.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/n8pTPFf/18.png">Collect</button>
</div>
<div class="item kanan">
<img src="https://i.ibb.co/RDWJfXk/19.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/RDWJfXk/19.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/rkkQqXM/20.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/rkkQqXM/20.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/jTsg4BQ/21.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/jTsg4BQ/21.png">Collect</button>
</div>
<div class="item kiri">
<img src="https://i.ibb.co/v332bhy/4.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/v332bhy/4.png">Collect</button>
</div>
<div class="item tengah">
<img src="https://i.ibb.co/9sw3NZK/5.png">
<button type="button" onclick="open_reward_confirmation(this)" src="https://i.ibb.co/9sw3NZK/5.png">Collect</button>
</div>
</div> <!--- scroll --->
<script src="js/popup.js"></script>