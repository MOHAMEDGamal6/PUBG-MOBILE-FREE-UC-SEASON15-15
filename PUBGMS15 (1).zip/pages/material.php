<div class="menu-notify">
<a href="javascript:;" onclick="buka('pages/weapon');"><div class="menu-notify-change">Change Reward</div></a>
<div class="menu-notify-icon"><i class="zmdi zmdi-info-outline"></i></div>
<div class="menu-notify-txt">Hi survivor, this is the other reward for you</div>
</div> <!--- menu-notify --->
<div class="scroll">
<div class="balance kanan">
<div class="balance-content-other">
<div class="balance-currency">15 Unit</div>
<img src="img/other/material.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/material.png">Collect</button>
</div>
<div class="balance kiri">
<div class="balance-content-other">
<div class="balance-currency">5 Unit</div>
<img src="img/other/material.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/material.png">Collect</button>
</div>
<div class="balance tengah">
<div class="balance-content-other">
<div class="balance-currency">10 Unit</div>
<img src="img/other/material.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/material.png">Collect</button>
</div>
<div class="balance kanan">
<div class="balance-content-other">
<div class="balance-currency">30 Unit</div>
<img src="img/other/material.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/material.png">Collect</button>
</div>
<div class="balance kiri">
<div class="balance-content-other">
<div class="balance-currency">20 Unit</div>
<img src="img/other/material.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/material.png">Collect</button>
</div>
<div class="balance tengah">
<div class="balance-content-other">
<div class="balance-currency">25 Unit</div>
<img src="img/other/material.png">
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/material.png">Collect</button>
</div>
</div> <!--- scroll --->
<script src="js/popup.js"></script>