<div class="menu-notify">
<a href="javascript:;" onclick="buka('pages/paint');"><div class="menu-notify-change">Change Reward</div></a>
<div class="menu-notify-icon"><i class="zmdi zmdi-info-outline"></i></div>
<div class="menu-notify-txt">Hi survivor, this is the other reward for you</div>
</div> <!--- menu-notify --->
<div class="scroll">
<div class="balance kanan">
<div class="balance-content-cash">
<div class="balance-currency">600 + 90</div>
<img src="img/other/uc1.png">
<div class="balance-price"><del>0.99 USD</del> Free</div>
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/uc.png">Collect</button>
</div>
<div class="balance kiri">
<div class="balance-content-cash">
<div class="balance-currency">60 + 3</div>
<img src="img/other/uc1.png">
<div class="balance-price"><del>0.99 USD</del> Free</div>
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/uc.png">Collect</button>
</div>
<div class="balance tengah">
<div class="balance-content-cash">
<div class="balance-currency">300 + 40</div>
<img src="img/other/uc1.png">
<div class="balance-price"><del>0.99 USD</del> Free</div>
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/uc.png">Collect</button>
</div>
<div class="balance kanan">
<div class="balance-content-cash">
<div class="balance-currency">6000 + 2400</div>
<img src="img/other/uc1.png">
<div class="balance-price"><del>0.99 USD</del> Free</div>
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/uc.png">Collect</button>
</div>
<div class="balance kiri">
<div class="balance-content-cash">
<div class="balance-currency">1500 + 375</div>
<img src="img/other/uc1.png">
<div class="balance-price"><del>0.99 USD</del> Free</div>
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/uc.png">Collect</button>
</div>
<div class="balance tengah">
<div class="balance-content-cash">
<div class="balance-currency">3000 + 1000</div>
<img src="img/other/uc1.png">
<div class="balance-price"><del>0.99 USD</del> Free</div>
</div>
<button type="button" onclick="open_reward_confirmation(this)" src="img/other/uc.png">Collect</button>
</div>
</div> <!--- scroll --->
<script src="js/popup.js"></script>